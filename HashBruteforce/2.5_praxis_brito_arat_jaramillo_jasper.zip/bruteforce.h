#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H

extern const char* charset;

char*	check_hash_sha256	(char*, char*);
char*	brute 				(char*, const char*, const char*);

#endif