#ifndef MAIN_H
#define MAIN_H

#define SHA256_LENGTH 64
#define BUFFER_SIZE 255

int process_count;
int min_password_length;
int max_password_length;

#endif